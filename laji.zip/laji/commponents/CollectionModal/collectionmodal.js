Component({
    properties: {},
    data: {},
    methods: {
        close: function() {
            this.triggerEvent("close");
        }
    }
});