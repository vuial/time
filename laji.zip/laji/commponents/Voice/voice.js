Component({
    properties: {
        time: Number
    },
    data: {},
    methods: {}
});