function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = e(require("./source/local")), n = require("./service/index"), a = require("./utils/aes"), o = require("./utils/Const"), r = e(require("./service/channel")), c = require("./utils/util");

App({
    channelId: r.default.get(),
    onLaunch: function(e) {
        var t = this;
        r.default.set(e.query["channel-id"]), this.channelId = r.default.get(), wx.getSystemInfo({
            success: function(e) {
                -1 != e.model.search("iPhone X") ? t.gloabalData.iPhoneX = !0 : t.gloabalData.iPhoneX = !1;
            }
        });
    },
    onShow: function() {
        this.forceUpdate(), this.forceClear(), this.getSource();
    },
    gloabalData: {
        iPhoneX: !1,
        source: "",
        windowWidth: 0,
        windowHeight: 0
    },
    forceClear: function() {
        (0, n.queryClear)().then(function(e) {
            0 === e.code && (wx.removeStorageSync(o.LOCALSTORE_DATA), wx.removeStorageSync(o.LOCALSTORE_DATA_NEW), 
            wx.removeStorageSync(o.SHOULDINITALL), wx.removeStorageSync(o.ISTODAYGETHOT));
        }).catch(function(e) {});
    },
    getSource: function() {
        var e = this;
        wx.removeStorageSync(o.LOCALSTORE_DATA), wx.removeStorageSync(o.SEARCH_HISTORY_CACHE);
        var r = void 0;
        try {
            r = JSON.parse(wx.getStorageSync(o.LOCALSTORE_DATA_NEW));
        } catch (e) {
            r = t.default;
        }
        var i = r[4].findIndex(function(e) {
            return "渣男" === e.name;
        });
        i > -1 && (r[4] = r[4].splice(i, 1));
        var l = r[4].findIndex(function(e) {
            return "渣女" === e.name;
        });
        l > -1 && (r[4] = r[4].splice(l, 1)), this.gloabalData.source = r, (0, c.shouldInitAll)() && (0, 
        n.queryAll)().then(function(t) {
            if (0 === t.code && t.data) {
                var n = (0, a.Decrypt)(t.data), r = JSON.parse(n);
                r[1] && r[1].length && r[2] && r[2].length && r[3] && r[3].length && r[4] && r[4].length && (e.gloabalData.source = r, 
                wx.setStorageSync(o.LOCALSTORE_DATA_NEW, n));
            }
        }).catch(function(e) {
            console.log(e);
        });
    },
    forceUpdate: function() {
        if (wx.getUpdateManager) {
            var e = wx.getUpdateManager();
            e.onCheckForUpdate(function(e) {
                console.log("is need update ", e.hasUpdate);
            }), e.onUpdateReady(function() {
                wx.showModal({
                    title: "更新提示",
                    content: "新版本已经准备好，是否重启应用？",
                    success: function(t) {
                        t.confirm && (wx.removeStorageSync(o.CAN_SHOW_CARD_COLLECTION_TIP), e.applyUpdate());
                    }
                });
            }), e.onUpdateFailed(function() {
                wx.showModal({
                    title: "更新提示",
                    content: "新版本下载失败",
                    showCancel: !1
                });
            });
        }
    }
});