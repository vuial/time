function e(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, r) {
            function n(i, a) {
                try {
                    var s = t[i](a), u = s.value;
                } catch (e) {
                    return void r(e);
                }
                if (!s.done) return Promise.resolve(u).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(u);
            }
            return n("next");
        });
    };
}

require("../../service/index"), require("../../utils/aes"), require("../../utils/util");

var t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../libs/regenerator-runtime/runtime")), r = getApp();

Page({
    data: {
        cats: 1,
        list: [],
        title: "",
        sub: "",
        ask: "",
        askList: [],
        img: "",
        bgColor: "",
        selectedItem: "",
        loadingTip: ""
    },
    onLoad: function(e) {
        var t = e.type;
        this.getList(t);
        var r = "", n = "", i = "", a = [], s = "../../source/images/icon/", u = "";
        switch (t) {
          case "1":
            r = "湿垃圾是指:", n = "易腐垃圾，食材废料，剩菜剩饭，过期食品，瓜皮果壳，绿植，中药等生活废弃物", i = "湿垃圾投放要求", a = [ "液体的食物垃圾如牛奶等，应直接倒入下水口", "有包装的湿垃圾应与包装分开投放对应的垃圾容器内" ], 
            s += "icon-1.png", u = "#664035";
            break;

          case "2":
            r = "干垃圾是指:", n = "干垃圾是指除有害垃圾、湿垃圾、可回收垃圾以外的其他生活废弃物", i = "干垃圾投放要求", a = [ "尽量沥干水分", "难以辨别的垃圾应投入干垃圾内" ], 
            s += "icon-2.png", u = "#2C2B27";
            break;

          case "3":
            r = "可回收物是指:", n = "废纸张、废塑料、废金属、废玻璃、废织物等适宜回收，可循环利用的废弃物", i = "可回收物投放要求", a = [ "轻投轻放", "洁净干燥，避免污染", "废纸尽量平整", "立体包装物请清空内容物，清洁压扁后投放", "有尖锐边角的，应包裹后投放" ], 
            s += "icon-3.png", u = "#104883";
            break;

          case "4":
            r = "有害垃圾是指:", n = "对人体健康或者自然环境造成直接或潜在危害的废弃物", i = "有害垃圾投放要求", a = [ "投放时请注意轻放", "易破损的请连带包装或包裹后轻放", "如易挥发，请密封后投放" ], 
            s += "icon-4.png", u = "#E43122";
        }
        this.setData({
            cats: t,
            title: r,
            sub: n,
            ask: i,
            askList: a,
            img: s,
            bgColor: u
        });
    },
    onPullDownRefresh: function() {
        this.getList();
    },
    bindCellType: function(e) {
        var t = e.currentTarget.dataset.cats, r = e.currentTarget.dataset.name, n = JSON.stringify({
            type: t,
            name: r
        });
        wx.navigateTo({
            url: "../card/card?item=" + n
        });
    },
    getList: function(n) {
        var i = this;
        return e(t.default.mark(function e() {
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    i.setData({
                        list: r.gloabalData.source[n]
                    });

                  case 1:
                  case "end":
                    return e.stop();
                }
            }, e, i);
        }))();
    }
});