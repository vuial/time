function e(e) {
    if (Array.isArray(e)) {
        for (var t = 0, a = Array(e.length); t < e.length; t++) a[t] = e[t];
        return a;
    }
    return Array.from(e);
}

var t = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var a = arguments[t];
        for (var s in a) Object.prototype.hasOwnProperty.call(a, s) && (e[s] = a[s]);
    }
    return e;
}, a = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../source/local")), s = getApp();

Page({
    data: {
        iPhoneX: s.gloabalData.iPhoneX,
        count: 5,
        pageIndex: 0,
        score: 0,
        step: 0,
        showResult: !1,
        provideList: [],
        selectedList: [],
        colorDic: {
            1: "#664035",
            2: "#2C2B27",
            3: "#104883",
            4: "#E43122"
        }
    },
    onLoad: function(e) {
        this.start();
    },
    onShow: function() {},
    start: function() {
        for (var s = [].concat(e(a.default[1]), e(a.default[2]), e(a.default[3]), e(a.default[4])), r = [], n = [], o = 0; o < this.data.count; o++) {
            var c = function() {
                var e = parseInt(Math.random() * s.length);
                return s.splice(e, 1)[0];
            }(), i = t({}, c, {
                type: this.getType(c.cats)
            });
            r.push(i), n.push(i);
        }
        this.setData({
            pageIndex: 0,
            showResult: !1,
            score: 0,
            step: 100 / this.data.count,
            provideList: r,
            selectedList: n
        });
    },
    selectBin: function(e) {
        var t = e.currentTarget.dataset.cats, a = this.data, s = a.provideList, r = a.selectedList, n = a.pageIndex, o = a.count, c = a.score, i = a.step;
        t === s[n].cats ? (r[n].result = !0, c += i, console.log("yes")) : (r[n].result = !1, 
        console.log("no")), r[n].selectCats = t, r[n].selectType = this.getType(t), n < o - 1 ? this.setData({
            selectedList: r,
            score: c,
            pageIndex: ++this.data.pageIndex
        }) : this.setData({
            selectedList: r,
            score: c,
            showResult: !0
        });
    },
    getType: function(e) {
        var t = void 0;
        switch (e) {
          case "1":
            t = "湿垃圾";
            break;

          case "2":
            t = "干垃圾";
            break;

          case "3":
            t = "可回收物";
            break;

          case "4":
            t = "有害垃圾";
        }
        return t;
    },
    catchTouchMove: function(e) {
        return !1;
    },
    backHome: function() {
        var e = getCurrentPages(), t = e.findIndex(function(e) {
            return "pages/index/index" === e.__route__;
        });
        -1 === t ? wx.navigateTo({
            url: "../index/index"
        }) : wx.navigateBack({
            delta: e.length - 1 - t
        });
    }
});