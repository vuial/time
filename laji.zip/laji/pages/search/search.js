function t(t) {
    return function() {
        var e = t.apply(this, arguments);
        return new Promise(function(t, a) {
            function r(n, s) {
                try {
                    var i = e[n](s), c = i.value;
                } catch (t) {
                    return void a(t);
                }
                if (!i.done) return Promise.resolve(c).then(function(t) {
                    r("next", t);
                }, function(t) {
                    r("throw", t);
                });
                t(c);
            }
            return r("next");
        });
    };
}

function e(t) {
    if (Array.isArray(t)) {
        for (var e = 0, a = Array(t.length); e < t.length; e++) a[e] = t[e];
        return a;
    }
    return Array.from(t);
}

var a = require("../../service/index"), r = require("../../utils/Const"), n = require("../../service/voice"), s = require("../../service/camera"), i = require("../../utils/util"), c = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../libs/regenerator-runtime/runtime")), o = getApp(), u = void 0;

Page({
    data: {
        searchVal: "",
        searchResults: [],
        selectedItem: "",
        isSearching: !1,
        hotList: [],
        localHistoryList: [],
        showVoice: !1,
        time: 0,
        showCamera: !0
    },
    get list() {
        return [].concat(e(o.gloabalData.source[1]), e(o.gloabalData.source[2]), e(o.gloabalData.source[3]), e(o.gloabalData.source[4]));
    },
    onLoad: function(t) {
        var e = t.search;
        e && (this.setData({
            searchVal: e
        }), this.searchValue(e));
    },
    onShow: function() {
        this.getHotList(), this.getLocalHistoryList();
    },
    bindSearchVal: function(t) {
        var e = t.detail.value;
        e ? (this.setData({
            searchVal: e
        }), this.searchValue(e)) : this.setData({
            searchResults: [],
            searchVal: e
        });
    },
    searchValue: function(t) {
        var e = this;
        if (t) {
            var a = this.list.filter(function(e) {
                return e.name.includes(t);
            });
            a.length ? (a.sort(function(e, a) {
                return a.name === t ? 1 : -1;
            }), this.setData({
                searchResults: a
            }, function() {
                e.list.filter(function(e) {
                    return e.name === t;
                }).length || e.searchFromServer(t);
            })) : this.setData({
                searchResults: a
            }, function() {
                e.searchFromServer(t);
            });
        }
    },
    manualSearch: function() {
        var t = this.data.searchResults;
        if (t.length) {
            var e = {
                type: t[0].cats,
                name: t[0].name
            };
            this.goCard(e);
        }
    },
    searchFromServer: function(e) {
        var a = this;
        return t(c.default.mark(function t() {
            var r, n;
            return c.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = a.data.searchResults, e) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return");

                  case 3:
                    return t.prev = 3, t.next = 6, a.searchAction(e);

                  case 6:
                    (n = t.sent) && (r.unshift(n), a.updateLocalData(n), a.setData({
                        searchResults: r
                    })), t.next = 13;
                    break;

                  case 10:
                    t.prev = 10, t.t0 = t.catch(3), console.log(t.t0);

                  case 13:
                  case "end":
                    return t.stop();
                }
            }, t, a, [ [ 3, 10 ] ]);
        }))();
    },
    updateLocalData: function(t) {
        o.gloabalData.source[t.cats] = o.gloabalData.source[t.cats].concat(t);
    },
    bindClearSearch: function() {
        this.setData({
            searchVal: "",
            searchResults: []
        });
    },
    bindCellType: function(t) {
        var e = {
            type: t.currentTarget.dataset.cats,
            name: t.currentTarget.dataset.name
        };
        this.goCard(e);
    },
    goCard: function(e) {
        var r = this;
        return t(c.default.mark(function t() {
            return c.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, (0, a.putHot)(e.name);

                  case 3:
                    t.next = 8;
                    break;

                  case 5:
                    t.prev = 5, t.t0 = t.catch(0), console.log(t.t0);

                  case 8:
                    r.recordLocal({
                        cats: e.type,
                        name: e.name
                    }), wx.navigateTo({
                        url: "../card/card?item=" + JSON.stringify(e)
                    });

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, t, r, [ [ 0, 5 ] ]);
        }))();
    },
    searchAction: function(t) {
        var e = this;
        return new Promise(function(r, n) {
            u && clearTimeout(u), u = setTimeout(function() {
                e.setData({
                    isSearching: !0
                }), (0, a.queryOne)(t).then(function(t) {
                    0 === t.code && t.data ? r(t.data) : r();
                }).catch(function(t) {
                    return r();
                }).then(function() {
                    e.setData({
                        isSearching: !1
                    });
                });
            }, 500);
        });
    },
    getHotList: function() {
        var e = this;
        return t(c.default.mark(function t() {
            var n, s;
            return c.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!(n = (0, i.isTodayGetHot)())) {
                        t.next = 4;
                        break;
                    }
                    return e.setData({
                        hotList: n
                    }), t.abrupt("return");

                  case 4:
                    return t.prev = 4, t.next = 7, (0, a.queryHot)();

                  case 7:
                    0 === (s = t.sent).code && Array.isArray(s.data) && (e.setData({
                        hotList: s.data
                    }), wx.setStorageSync(r.ISTODAYGETHOT, JSON.stringify({
                        date: new Date().toLocaleDateString(),
                        data: s.data
                    }))), t.next = 14;
                    break;

                  case 11:
                    t.prev = 11, t.t0 = t.catch(4), console.log(t.t0);

                  case 14:
                  case "end":
                    return t.stop();
                }
            }, t, e, [ [ 4, 11 ] ]);
        }))();
    },
    getLocalHistoryList: function() {
        var t = [];
        try {
            var e = wx.getStorageSync(r.SEARCH_HISTORY_CACHE_NEW);
            t = JSON.parse(e) || [];
        } catch (e) {
            t = [];
        }
        this.setData({
            localHistoryList: t
        });
    },
    recordLocal: function(t) {
        var e = this.data.localHistoryList, a = e.findIndex(function(e) {
            return e.name === t.name;
        });
        a > -1 && e.splice(a, 1), e.length >= 10 && e.pop(), e.unshift(t), wx.setStorageSync(r.SEARCH_HISTORY_CACHE_NEW, JSON.stringify(e));
    },
    clearLocalHistory: function() {
        this.setData({
            localHistoryList: []
        }), wx.removeStorageSync(r.SEARCH_HISTORY_CACHE_NEW);
    },
    touchVoice: function() {
        var t = this;
        this.start = !0, setTimeout(function() {
            t.start ? (t.setData({
                showVoice: !0,
                time: 5
            }, function() {
                t.timeout && clearTimeout(t.timeout), t.countTime();
            }), t.startVoice()) : wx.showToast({
                title: "请长按录音",
                icon: "none",
                duration: 2e3
            });
        }, 200);
    },
    countTime: function() {
        var t = this;
        this.data.time > 0 ? this.timeout = setTimeout(function() {
            t.setData({
                time: t.data.time - 1
            }, function() {
                return t.countTime();
            });
        }, 1e3) : this.stopVoice();
    },
    startVoice: function() {
        var e = this;
        return t(c.default.mark(function t() {
            var a;
            return c.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, (0, n.startVoice)();

                  case 3:
                    if (a = t.sent) {
                        t.next = 8;
                        break;
                    }
                    throw new Error("未识别");

                  case 8:
                    e.findItem(a);

                  case 9:
                    t.next = 15;
                    break;

                  case 11:
                    t.prev = 11, t.t0 = t.catch(0), console.log(t.t0), wx.showToast({
                        title: t.t0.message || "出错，请稍后再试",
                        icon: "none",
                        duration: 2e3
                    });

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, t, e, [ [ 0, 11 ] ]);
        }))();
    },
    stopVoice: function() {
        this.setData({
            showVoice: !1
        }), this.start = !1, (0, n.stopVoice)();
    },
    findItem: function(t) {
        var e = this.list.find(function(e) {
            return e.name === t;
        });
        if (e) {
            var a = JSON.stringify({
                type: e.cats,
                name: e.name
            });
            wx.navigateTo({
                url: "../card/card?item=" + a
            });
        } else this.setData({
            searchVal: t
        }), this.searchValue(t);
    },
    catchCamera: function() {
        var e = this;
        return t(c.default.mark(function t() {
            var a, r, n;
            return c.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, (0, s.ocrImage)();

                  case 3:
                    if (a = t.sent, r = a.code, n = a.data, 10 !== r) {
                        t.next = 10;
                        break;
                    }
                    return e.setData({
                        showCamera: !1
                    }), wx.showToast({
                        title: "出错，请稍后再试",
                        icon: "none",
                        duration: 2e3
                    }), t.abrupt("return");

                  case 10:
                    if (n) {
                        t.next = 14;
                        break;
                    }
                    throw new Error("未识别");

                  case 14:
                    e.findItem(n);

                  case 15:
                    t.next = 20;
                    break;

                  case 17:
                    t.prev = 17, t.t0 = t.catch(0), wx.showToast({
                        title: t.t0.message || "出错，请稍后再试",
                        icon: "none",
                        duration: 2e3
                    });

                  case 20:
                  case "end":
                    return t.stop();
                }
            }, t, e, [ [ 0, 17 ] ]);
        }))();
    }
});