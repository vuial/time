function t(t) {
    if (Array.isArray(t)) {
        for (var e = 0, n = Array(t.length); e < t.length; e++) n[e] = t[e];
        return n;
    }
    return Array.from(t);
}

function e(t) {
    return function() {
        var e = t.apply(this, arguments);
        return new Promise(function(t, n) {
            function a(o, i) {
                try {
                    var r = e[o](i), c = r.value;
                } catch (t) {
                    return void n(t);
                }
                if (!r.done) return Promise.resolve(c).then(function(t) {
                    a("next", t);
                }, function(t) {
                    a("throw", t);
                });
                t(c);
            }
            return a("next");
        });
    };
}

var n = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../libs/regenerator-runtime/runtime")), a = require("../../service/voice"), o = require("../../service/camera"), i = getApp();

Page({
    data: {
        iPhoneX: i.gloabalData.iPhoneX,
        showShare: !1,
        showCollection: !1,
        showVoice: !1,
        time: 0,
        contactX: 20,
        contactY: 375,
        showCamera: !0
    },
    onLoad: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(e) {
                i.gloabalData.windowWidth = e.windowWidth, i.gloabalData.windowHeight = e.windowHeight, 
                t.setData({
                    contactX: e.windowWidth - 70,
                    contactY: e.windowHeight - 175
                });
            }
        });
    },
    goSearch: function() {
        wx.navigateTo({
            url: "../search/search"
        });
    },
    goList: function(t) {
        wx.navigateTo({
            url: "../list/list?type=" + t
        });
    },
    bind1: function() {
        this.goList(1);
    },
    bind2: function() {
        this.goList(2);
    },
    bind3: function() {
        this.goList(3);
    },
    bind4: function() {
        this.goList(4);
    },
    showShare: function() {
        this.setData({
            showShare: !0
        });
    },
    openCollection: function() {
        this.setData({
            showCollection: !0
        });
    },
    closeShare: function() {
        this.setData({
            showShare: !1
        });
    },
    closeCollection: function() {
        this.setData({
            showCollection: !1
        });
    },
    openGame: function() {
        wx.navigateTo({
            url: "../game/game"
        });
    },
    catchVoice: function() {},
    touchVoice: function() {
        var t = this;
        this.start = !0, setTimeout(function() {
            t.start ? (t.setData({
                showVoice: !0,
                time: 5
            }, function() {
                t.timeout && clearTimeout(t.timeout), t.countTime();
            }), t.startVoice()) : wx.showToast({
                title: "请长按录音",
                icon: "none",
                duration: 2e3
            });
        }, 200);
    },
    countTime: function() {
        var t = this;
        this.data.time > 0 ? this.timeout = setTimeout(function() {
            t.setData({
                time: t.data.time - 1
            }, function() {
                return t.countTime();
            });
        }, 1e3) : this.stopVoice();
    },
    startVoice: function() {
        var t = this;
        return e(n.default.mark(function e() {
            var o;
            return n.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, (0, a.startVoice)();

                  case 3:
                    if (o = e.sent) {
                        e.next = 8;
                        break;
                    }
                    throw new Error("未识别");

                  case 8:
                    t.findItem(o);

                  case 9:
                    e.next = 15;
                    break;

                  case 11:
                    e.prev = 11, e.t0 = e.catch(0), console.log(e.t0), wx.showToast({
                        title: e.t0.message || "出错，请稍后再试",
                        icon: "none",
                        duration: 2e3
                    });

                  case 15:
                  case "end":
                    return e.stop();
                }
            }, e, t, [ [ 0, 11 ] ]);
        }))();
    },
    stopVoice: function() {
        this.setData({
            showVoice: !1
        }), this.start = !1, (0, a.stopVoice)();
    },
    findItem: function(e) {
        var n = [].concat(t(i.gloabalData.source[1]), t(i.gloabalData.source[2]), t(i.gloabalData.source[3]), t(i.gloabalData.source[4])).find(function(t) {
            return t.name === e;
        });
        if (n) {
            var a = JSON.stringify({
                type: n.cats,
                name: n.name
            });
            wx.navigateTo({
                url: "../card/card?item=" + a
            });
        } else wx.navigateTo({
            url: "../search/search?search=" + e
        });
    },
    contactChange: function(t) {},
    catchCamera: function() {
        var t = this;
        return e(n.default.mark(function e() {
            var a, i, r;
            return n.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, (0, o.ocrImage)();

                  case 3:
                    if (a = e.sent, i = a.code, r = a.data, 10 !== i) {
                        e.next = 10;
                        break;
                    }
                    return t.setData({
                        showCamera: !1
                    }), wx.showToast({
                        title: "出错，请稍后再试",
                        icon: "none",
                        duration: 2e3
                    }), e.abrupt("return");

                  case 10:
                    if (r) {
                        e.next = 14;
                        break;
                    }
                    throw new Error("未识别");

                  case 14:
                    t.findItem(r);

                  case 15:
                    e.next = 20;
                    break;

                  case 17:
                    e.prev = 17, e.t0 = e.catch(0), wx.showToast({
                        title: e.t0.message || "出错，请稍后再试",
                        icon: "none",
                        duration: 2e3
                    });

                  case 20:
                  case "end":
                    return e.stop();
                }
            }, e, t, [ [ 0, 17 ] ]);
        }))();
    }
});