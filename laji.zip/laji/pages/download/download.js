var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/util"));

getApp();

Page({
    data: {
        cats: [ {
            title: "湿垃圾",
            imageSrc: "../../images/household_food_waste_icon.png"
        }, {
            title: "干垃圾",
            imageSrc: "../../images/residual_waste_icon.png"
        }, {
            title: "可回收物",
            imageSrc: "../../images/recyclable_waste_icon.png"
        }, {
            title: "有害垃圾",
            imageSrc: "../../images/hazardous_waste_icon.png"
        } ],
        downloads: [ "/images/wsg_poster.png", "/images/wsg_office_poster.png" ],
        writePhotosAlbumStatus: 0
    },
    onLoad: function() {
        var t = this;
        wx.getSetting({
            success: function(e) {
                void 0 === e.authSetting["scope.writePhotosAlbum"] ? t.setData({
                    writePhotosAlbumStatus: 0
                }) : !0 === e.authSetting["scope.writePhotosAlbum"] ? t.setData({
                    writePhotosAlbumStatus: 1
                }) : !1 === e.authSetting["scope.writePhotosAlbum"] && t.setData({
                    writePhotosAlbumStatus: 2
                });
            }
        }), wx.showShareMenu({
            withShareTicket: !0
        });
    },
    onShareAppMessage: function(t) {
        return {
            title: "垃圾分类指南",
            path: "/pages/index/index",
            imageUrl: "../../images/cover_1.png"
        };
    },
    saveImageToAlbum: function(e) {
        var s = this;
        wx.saveImageToPhotosAlbum({
            filePath: this.data.downloads[e.currentTarget.dataset.downloadIndex],
            success: function() {
                s.setData({
                    writePhotosAlbumStatus: 3
                }), setTimeout(function() {
                    s.setData({
                        writePhotosAlbumStatus: 1
                    });
                }, 1e3), (0, t.default)(104);
            }
        });
    },
    authorizeWritePhotosAlbum: function(t) {
        var e = this;
        wx.authorize({
            scope: "scope.writePhotosAlbum",
            success: function() {
                e.saveImageToAlbum(t);
            },
            fail: function() {
                e.setData({
                    writePhotosAlbumStatus: 2
                });
            }
        });
    },
    openSetting: function(t) {
        void 0 === t.detail.authSetting["scope.writePhotosAlbum"] ? this.setData({
            writePhotosAlbumStatus: 0
        }) : !0 === t.detail.authSetting["scope.writePhotosAlbum"] ? (this.setData({
            writePhotosAlbumStatus: 1
        }), this.saveImageToAlbum(t)) : 0 == t.detail.authSetting["scope.writePhotosAlbum"] && this.setData({
            writePhotosAlbumStatus: 2
        });
    }
});