Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.isTodayGetHot = exports.shouldInitAll = exports.debounce = exports.formatNumber = exports.formatTime = void 0;

var t = require("./Const"), e = (exports.formatTime = function(t) {
    var r = t.getFullYear(), o = t.getMonth() + 1, n = t.getDate(), a = t.getHours(), u = t.getMinutes(), i = t.getSeconds();
    return [ r, o, n ].map(e).join("/") + " " + [ a, u, i ].map(e).join(":");
}, exports.formatNumber = function(t) {
    return (t = t.toString())[1] ? t : "0" + t;
});

exports.debounce = function(t) {
    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 200, o = null;
    return function() {
        for (var n = arguments.length, a = Array(n), u = 0; u < n; u++) a[u] = arguments[u];
        null !== o && clearTimeout(o), o = setTimeout(function() {
            t.apply(e, a);
        }, r);
    };
}, exports.shouldInitAll = function() {
    var e = wx.getStorageSync(t.SHOULDINITALL);
    return e ? !(Date.now() - parseInt(e) < 6e4) && (wx.setStorageSync(t.SHOULDINITALL, Date.now().toString()), 
    !0) : (wx.setStorageSync(t.SHOULDINITALL, Date.now().toString()), !0);
}, exports.isTodayGetHot = function() {
    try {
        var e = JSON.parse(wx.getStorageSync(t.ISTODAYGETHOT)), r = e.date, o = e.data;
        return r === new Date().toLocaleDateString() && o;
    } catch (t) {
        return !1;
    }
};