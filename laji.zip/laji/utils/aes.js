function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.Decrypt = function(e) {
    var n = r.default.parse(e).toString(), l = u.default.parse(n), o = r.default.stringify(l);
    return s.default.decrypt(o, a, {
        iv: i
    }).toString(t.default).toString();
}, exports.Encrypt = function(e) {
    var r = t.default.parse(e);
    return s.default.encrypt(r, a, {
        iv: i
    }).toString();
};

var t = e(require("../libs/crypto-js/enc-utf8")), r = e(require("../libs/crypto-js/enc-base64")), u = e(require("../libs/crypto-js/enc-hex")), s = e(require("../libs/crypto-js/aes")), a = t.default.parse("UtTotPNuCOU49u0S"), i = t.default.parse("F5rVCl1n7KOpD2v9");