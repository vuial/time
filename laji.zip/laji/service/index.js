Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryClear = exports.querySearch = exports.uploadImage = exports.uploadVoice = exports.queryList = exports.putHot = exports.queryHot = exports.queryOne = exports.queryAll = void 0;

var t = require("../utils/aes"), e = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("./channel")), r = function(r) {
    var o = r.path, a = r.method, u = void 0 === a ? "get" : a, n = r.params, p = void 0 === n ? {} : n, s = r.data, i = void 0 === s ? {} : s, c = " " + o + "?appversion=101.27&channel-id=" + e.default.get();
    for (var d in p) c += "&" + d + "=" + p[d];
    return new Promise(function(e, r) {
        wx.request({
            url: c,
            method: u,
            data: i,
            header: {
                "content-message": (0, t.Encrypt)(Date.now().toString())
            },
            success: function(t) {
                e(t.data);
            },
            fail: function(t) {
                r(t);
            }
        });
    });
};

exports.queryAll = function() {
    return r({
        path: "/all"
    });
}, exports.queryOne = function(t) {
    return r({
        path: "/" + t
    });
}, exports.queryHot = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 8;
    return r({
        path: "/hot",
        params: {
            num: t
        }
    });
}, exports.putHot = function(t) {
    return r({
        path: "/" + t,
        method: "put"
    });
}, exports.queryList = function(t) {
    return r({
        path: "/list/" + t
    });
}, exports.uploadVoice = function(t) {
    return r({
        path: "/voice",
        method: "post",
        data: t
    });
}, exports.uploadImage = function(t) {
    return r({
        path: "/camera",
        method: "post",
        data: t
    });
}, exports.querySearch = function(t) {
    return r({
        path: "/search/" + t
    });
}, exports.queryClear = function() {
    return r({
        path: "/clear"
    });
};