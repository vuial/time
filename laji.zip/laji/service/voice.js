function e(e) {
    return function() {
        var r = e.apply(this, arguments);
        return new Promise(function(e, t) {
            function n(a, o) {
                try {
                    var u = r[a](o), i = u.value;
                } catch (e) {
                    return void t(e);
                }
                if (!u.done) return Promise.resolve(i).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(i);
            }
            return n("next");
        });
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.stopVoice = exports.startVoice = void 0;

var r = require("./index"), t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../libs/regenerator-runtime/runtime")), n = wx.getFileSystemManager();

exports.startVoice = function() {
    return new Promise(function(a, o) {
        wx.startRecord({
            success: function() {
                var u = e(t.default.mark(function e(u) {
                    var i, s, c, p, f, d;
                    return t.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            i = u.tempFilePath, s = i.split("."), c = s[s.length - 1], p = void 0, e.t0 = c.toUpperCase(), 
                            e.next = "PCM" === e.t0 ? 7 : "WAV" === e.t0 ? 9 : "AMR" === e.t0 ? 11 : "SILK" === e.t0 ? 13 : 15;
                            break;

                          case 7:
                            return p = 1, e.abrupt("break", 16);

                          case 9:
                            return p = 2, e.abrupt("break", 16);

                          case 11:
                            return p = 3, e.abrupt("break", 16);

                          case 13:
                            return p = 4, e.abrupt("break", 16);

                          case 15:
                            p = "";

                          case 16:
                            if (f = n.readFileSync(i, "base64"), p && f) {
                                e.next = 20;
                                break;
                            }
                            return o(new TypeError("获取音频失败")), e.abrupt("return");

                          case 20:
                            return wx.showLoading({
                                title: "正在识别..",
                                mask: !0
                            }), e.prev = 21, e.next = 24, (0, r.uploadVoice)({
                                speech: f,
                                format: p
                            });

                          case 24:
                            0 === (d = e.sent).code ? a(d.data) : o(new TypeError(d.msg)), e.next = 31;
                            break;

                          case 28:
                            e.prev = 28, e.t1 = e.catch(21), o(e.t1);

                          case 31:
                            return e.prev = 31, wx.hideLoading(), e.finish(31);

                          case 34:
                          case "end":
                            return e.stop();
                        }
                    }, e, void 0, [ [ 21, 28, 31, 34 ] ]);
                }));
                return function(e) {
                    return u.apply(this, arguments);
                };
            }(),
            fail: function(e) {
                o(e);
            }
        });
    });
}, exports.stopVoice = function() {
    wx.stopRecord();
};