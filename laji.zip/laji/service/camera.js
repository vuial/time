function e(e) {
    return function() {
        var r = e.apply(this, arguments);
        return new Promise(function(e, t) {
            function n(i, u) {
                try {
                    var a = r[i](u), o = a.value;
                } catch (e) {
                    return void t(e);
                }
                if (!a.done) return Promise.resolve(o).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(o);
            }
            return n("next");
        });
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.ocrImage = void 0;

var r = require("./index"), t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../libs/regenerator-runtime/runtime")), n = wx.getFileSystemManager();

exports.ocrImage = function() {
    return new Promise(function(i, u) {
        wx.chooseImage({
            sizeType: [ "compressed" ],
            sourceType: [ "camera" ],
            success: function() {
                var a = e(t.default.mark(function e(a) {
                    var o, s;
                    return t.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (o = n.readFileSync(a.tempFilePaths[0], "base64")) {
                                e.next = 4;
                                break;
                            }
                            return u(new TypeError("获取照片失败")), e.abrupt("return");

                          case 4:
                            return wx.showLoading({
                                title: "正在识别..",
                                mask: !0
                            }), e.prev = 5, e.next = 8, (0, r.uploadImage)({
                                image: o
                            });

                          case 8:
                            s = e.sent, i(s), e.next = 15;
                            break;

                          case 12:
                            e.prev = 12, e.t0 = e.catch(5), u(e.t0);

                          case 15:
                            return e.prev = 15, wx.hideLoading(), e.finish(15);

                          case 18:
                          case "end":
                            return e.stop();
                        }
                    }, e, void 0, [ [ 5, 12, 15, 18 ] ]);
                }));
                return function(e) {
                    return a.apply(this, arguments);
                };
            }(),
            fail: function(e) {}
        });
    });
};